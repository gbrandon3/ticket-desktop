# Santi Inc: release web

Requiere Node.js 22.13 o superior (recomendado Node.js 24).

1. Descomprima todo el ZIP en una carpeta.
2. Abra una terminal en esa carpeta y ejecute: npm start
3. Abra http://localhost:3000 en el navegador.

En Windows también puede abrir iniciar_web.cmd.
Un solo servidor ejecuta la API y sirve el frontend compilado.
Las dependencias están incluidas: no necesita Flutter ni npm install.
Detenga el servidor con Ctrl+C.

Esta entrega no incluye datos ni credenciales. En una carpeta nueva,
complete el asistente de configuración inicial. Si actualiza una instalación,
detenga el servidor y conserve sus carpetas data y backups.

Para acceder desde un celular en la misma red, use la IP del computador
con el puerto 3000, por ejemplo http://192.168.1.10:3000.
